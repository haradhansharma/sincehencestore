<?php exit();?>
{
    "name": "wp_sincehence.store_2024-06-03_03-09-10",
    "backup_dir": "1",
    "backup_db": "1",
    "email": "haradhan.sharma@gmail.com",
    "date_time": "2024-06-03 03:09:am",
    "btime": 1717384150,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "https:\/\/sincehence.store",
    "backup_site_path": "\/home\/yzwigndt\/maxmix_html"
}